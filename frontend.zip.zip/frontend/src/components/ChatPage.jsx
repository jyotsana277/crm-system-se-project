import React from 'react'

const ChatPage = () => {
  return (
    <div>ChatPage</div>
  )
}

export default ChatPage